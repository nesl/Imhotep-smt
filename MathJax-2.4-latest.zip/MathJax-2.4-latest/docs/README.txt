The source files for the documentation are now kept in a separate
GitHub repository at

       https://github.com/mathjax/mathjax-docs

The HTML versions are now available at

       http://docs.mathjax.org/

where it is possible for you to submit corrections and modifications
directly to the documentation on line.
