
To run the active cruise example example:

1- Open the “active_cruise_control_Example.m” file inside Matlab
2- add "folder_path/ImhotepSMT/" to the Matlab path (File->Set path->Add folder)

OR

Edit the line:
imhotepSMTPath = './';  %path to Imhotep-SMT
by placing the path to the folder which contains ImhotepSMT.m

3- Run the file from the play button or by Debug->play active_cruise_control_Example.m