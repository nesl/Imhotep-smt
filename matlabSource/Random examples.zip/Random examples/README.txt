
To run the scalability test:

1- Open the “scalability_test.m” file inside Matlab
2- add "folder_path/ImhotepSMT/" to the Matlab path (File->Set path->Add folder)

OR

Edit the line:
imhotepSMTPath = '../../';  %path to Imhotep-SMT
by placing the path to the folder which contains ImhotepSMT.m

3- Run the file from the play button or by Debug->play scalability_test.m